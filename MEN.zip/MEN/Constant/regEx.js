var Constants =(function () {
    function Constants() {
    }
    Constants.emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    Constants.numberRegex = /^[0-9]+$/;
    Constants.ageRegEx = /^([0-9]{1,2})$/;
    return Constants;
}());
exports.Constants = Constants;